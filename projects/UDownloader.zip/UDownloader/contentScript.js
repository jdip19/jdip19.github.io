//Get all image elements in the current webpage
const images = Array.from(document.querySelectorAll('img'));

// Filter for PNG and JPEG images and return their URLs
const imageUrls = images
  .map(img => img.src)
  .filter(src => src.endsWith('.png') || src.endsWith('.jpg') || src.endsWith('.jpeg'));

// Save the image URLs in chrome.storage
chrome.storage.local.set({ imageUrls });

function getResizedSvg(callback) {
  chrome.storage.sync.get("svgSize", function (data) {
      const size = data.svgSize || 128; // Default size if not set

      const editButton = document.querySelector('#detail_edit_icon');
      if (editButton) editButton.click();

      setTimeout(() => {
          const svgElement = document.querySelector('.detail__editor__icon-holder svg');
          if (svgElement) {
              svgElement.setAttribute('width', size);
              svgElement.setAttribute('height', size);

              const serializer = new XMLSerializer();
              const svgString = serializer.serializeToString(svgElement);

              callback({ svgString, size });
          } else {
              callback({ error: "SVG element not found." });
          }
      }, 2000);
  });
}

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getSvg") {
      getResizedSvg((data) => {
          sendResponse(data);
      });
      return true; // Keeps the response open for async use
  }
});
