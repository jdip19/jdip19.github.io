Features
Keyboard Shortcuts:
SHIFT + ALT + C: Copy SVG Code.
SHIFT + ALT + D: Download SVG Icon.
Lightweight and efficient for seamless file handling.


How to Load the Extension
For Chrome/Edge:
Download the Extension Files:

Ensure all files (manifest.json, JavaScript, images, etc.) are in a single folder.
Enable Developer Mode:

Open Chrome/Edge.
Go to chrome://extensions (or edge://extensions for Edge).
Toggle on Developer Mode in the top-right corner.
Load the Extension:

Click Load unpacked.
Select the folder containing the extension files.
Verify Installation:

The extension icon should now appear in the browser toolbar.

Feedback & Discussion
For feedback or discussion, reach out:
<a href="https://www.linkedin.com/in/jaydip-upadhyay-32b231176/">Jaydip Upadhyay</a>